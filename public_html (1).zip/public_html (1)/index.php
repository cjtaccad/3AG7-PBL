<?php
// send everyone to the login page
header('Location: /login.php', true, 301);
exit;